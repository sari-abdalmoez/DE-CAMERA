use std::collections::VecDeque;
use std::ffi::c_int;

#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct Star {
    pub x: f32,
    pub y: f32,
    pub flux: f32,
    pub pixels: u32,
}

fn mean_std(data: &[u8], w: usize, h: usize, stride: usize) -> (f32, f32) {
    let mut n = 0f64;
    let mut sum = 0f64;
    let mut sq = 0f64;
    for y in 0..h {
        let row = &data[y * stride..y * stride + w];
        for &p in row {
            let v = p as f64;
            sum += v;
            sq += v * v;
            n += 1.0;
        }
    }
    if n == 0.0 {
        return (0.0, 0.0);
    }
    let m = sum / n;
    (m as f32, (sq / n - m * m).max(0.0).sqrt() as f32)
}

/// Safe core: detects compact bright connected components above
/// `mean + threshold_sigma * std` in a strided 8-bit gray image.
/// Returns measured candidates only; it never creates synthetic stars.
pub fn detect_stars(
    s: &[u8],
    wu: usize,
    hu: usize,
    st: usize,
    threshold_sigma: f32,
    dst: &mut [Star],
) -> usize {
    if wu <= 2 || hu <= 2 || st < wu || s.len() < (hu - 1) * st + wu {
        return 0;
    }
    let (m, sd) = mean_std(s, wu, hu, st);
    let th = (m + threshold_sigma.max(0.5) * sd).min(250.0);
    let mut seen = vec![false; wu * hu];
    let mut count = 0usize;
    let mut q: VecDeque<(usize, usize)> = VecDeque::new();

    for y in 1..hu - 1 {
        for x in 1..wu - 1 {
            let idx = y * wu + x;
            if seen[idx] || (s[y * st + x] as f32) <= th {
                continue;
            }
            q.clear();
            q.push_back((x, y));
            seen[idx] = true;
            let mut sx = 0f64;
            let mut sy = 0f64;
            let mut sf = 0f64;
            let mut n = 0u32;
            while let Some((cx, cy)) = q.pop_front() {
                let v = s[cy * st + cx] as f32;
                let flux = (v - th).max(0.0) as f64;
                sx += cx as f64 * flux;
                sy += cy as f64 * flux;
                sf += flux;
                n += 1;
                // Bounds-checked 4-neighbourhood (no usize underflow / overflow).
                let mut push = |nx: usize, ny: usize| {
                    let ni = ny * wu + nx;
                    if !seen[ni] && (s[ny * st + nx] as f32) > th {
                        seen[ni] = true;
                        q.push_back((nx, ny));
                    }
                };
                if cx > 0 {
                    push(cx - 1, cy);
                }
                if cx + 1 < wu {
                    push(cx + 1, cy);
                }
                if cy > 0 {
                    push(cx, cy - 1);
                }
                if cy + 1 < hu {
                    push(cx, cy + 1);
                }
            }
            // Reject isolated hot pixels and large saturated blobs.
            if (2..=80).contains(&n) && sf > 0.0 && count < dst.len() {
                let cx = (sx / sf) as f32;
                let cy = (sy / sf) as f32;
                if cx >= 1.0 && cy >= 1.0 && cx < (wu - 1) as f32 && cy < (hu - 1) as f32 {
                    dst[count] = Star {
                        x: cx,
                        y: cy,
                        flux: sf as f32,
                        pixels: n,
                    };
                    count += 1;
                }
            }
        }
    }
    count
}

/// C ABI entry point.
///
/// # Safety
/// `gray` must point to at least `(h-1)*stride + w` readable bytes and `out`
/// to `max_stars` writable `Star` entries.
#[no_mangle]
pub unsafe extern "C" fn sari_detect_stars(
    gray: *const u8,
    w: c_int,
    h: c_int,
    stride: c_int,
    threshold_sigma: f32,
    out: *mut Star,
    max_stars: c_int,
) -> c_int {
    if gray.is_null() || out.is_null() || w <= 2 || h <= 2 || stride < w || max_stars <= 0 {
        return -1;
    }
    let (wu, hu, st) = (w as usize, h as usize, stride as usize);
    // Last row of an Android Y plane is not guaranteed to be padded to `stride`.
    let len = (hu - 1) * st + wu;
    let s = std::slice::from_raw_parts(gray, len);
    let dst = std::slice::from_raw_parts_mut(out, max_stars as usize);
    detect_stars(s, wu, hu, st, threshold_sigma, dst) as c_int
}

#[no_mangle]
pub extern "C" fn sari_astro_version() -> *const std::ffi::c_char {
    b"SARI Astro Rust 1.0\0".as_ptr() as *const _
}

#[cfg(test)]
mod tests {
    use super::*;

    fn blank() -> Vec<Star> {
        vec![
            Star {
                x: 0.0,
                y: 0.0,
                flux: 0.0,
                pixels: 0
            };
            16
        ]
    }

    #[test]
    fn detects_measured_bright_component() {
        let (w, h, stride) = (32usize, 32usize, 32usize);
        let mut img = vec![10u8; w * h];
        for y in 14..18 {
            for x in 14..18 {
                img[y * stride + x] = 250;
            }
        }
        let mut out = blank();
        let n = unsafe {
            sari_detect_stars(
                img.as_ptr(),
                w as c_int,
                h as c_int,
                stride as c_int,
                3.0,
                out.as_mut_ptr(),
                16,
            )
        };
        assert!(n > 0);
        assert!((out[0].x - 15.5).abs() < 1.0);
        assert!((out[0].y - 15.5).abs() < 1.0);
    }

    #[test]
    fn empty_image_has_no_stars() {
        let img = vec![10u8; 32 * 32];
        let mut out = blank();
        let n = unsafe { sari_detect_stars(img.as_ptr(), 32, 32, 32, 3.0, out.as_mut_ptr(), 16) };
        assert_eq!(n, 0);
    }

    #[test]
    fn bright_border_does_not_panic() {
        // Regression: components touching the frame edge used to underflow/overflow indices.
        let (w, h) = (16usize, 16usize);
        let mut img = vec![5u8; w * h];
        for i in 0..w {
            img[i] = 255;
            img[(h - 1) * w + i] = 255;
        }
        for y in 0..h {
            img[y * w] = 255;
            img[y * w + w - 1] = 255;
        }
        let mut out = blank();
        let n = unsafe { sari_detect_stars(img.as_ptr(), 16, 16, 16, 1.0, out.as_mut_ptr(), 16) };
        assert!(n >= 0);
    }

    #[test]
    fn strided_buffer_without_last_row_padding() {
        let (w, h, stride) = (20usize, 20usize, 32usize);
        let mut img = vec![8u8; (h - 1) * stride + w];
        for y in 9..12 {
            for x in 9..12 {
                img[y * stride + x] = 240;
            }
        }
        let mut out = blank();
        let n = unsafe {
            sari_detect_stars(
                img.as_ptr(),
                w as c_int,
                h as c_int,
                stride as c_int,
                3.0,
                out.as_mut_ptr(),
                16,
            )
        };
        assert_eq!(n, 1);
    }

    #[test]
    fn rejects_invalid_arguments() {
        let mut out = blank();
        let n = unsafe { sari_detect_stars(std::ptr::null(), 8, 8, 8, 3.0, out.as_mut_ptr(), 16) };
        assert_eq!(n, -1);
    }
}
