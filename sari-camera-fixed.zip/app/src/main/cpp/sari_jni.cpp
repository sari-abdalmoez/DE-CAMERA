#include <jni.h>
#include <vector>
#include <exception>
#include "sari_engine.h"

// Every JNI entry point is exception-safe: an uncaught C++ exception (e.g. cv::Exception
// from OpenCV, std::bad_alloc) crossing the JNI boundary would abort the whole process.

static void throwEx(JNIEnv* e, const char* msg) {
    jclass c = e->FindClass("java/lang/IllegalArgumentException");
    if (c) { e->ThrowNew(c, msg); e->DeleteLocalRef(c); }
}

// Rust astro library (libsari_astro.so)
struct RustStar { float x, y, flux; unsigned pixels; };
extern "C" int sari_detect_stars(const uint8_t*, int, int, int, float, RustStar*, int);

extern "C" JNIEXPORT jstring JNICALL
Java_com_sari_camera_NativeEngine_nativeVersion(JNIEnv* e, jobject) {
    return e->NewStringUTF(sari_native_version());
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_sari_camera_NativeEngine_estimateBlur(JNIEnv* e, jobject, jobject buf, jint w, jint h, jint stride) {
    auto* p = (uint8_t*)e->GetDirectBufferAddress(buf);
    if (!p || w <= 0 || h <= 0 || stride < w) { throwEx(e, "Direct buffer required"); return 0; }
    if (e->GetDirectBufferCapacity(buf) < (jlong)(h - 1) * stride + w) { throwEx(e, "Buffer too small"); return 0; }
    try { return sari_estimate_blur(p, w, h, stride); } catch (...) { return 0; }
}

extern "C" JNIEXPORT jint JNICALL
Java_com_sari_camera_NativeEngine_processTileRGBA(JNIEnv* e, jobject, jobject in, jobject out, jint w, jint h, jfloat s) {
    auto* a = (uint8_t*)e->GetDirectBufferAddress(in);
    auto* b = (uint8_t*)e->GetDirectBufferAddress(out);
    if (!a || !b || w <= 0 || h <= 0) { throwEx(e, "Direct buffers required"); return -1; }
    const jlong need = (jlong)w * h * 4;
    if (e->GetDirectBufferCapacity(in) < need || e->GetDirectBufferCapacity(out) < need) { throwEx(e, "Buffer too small"); return -1; }
    try { return sari_process_rgba(a, b, w, h, s); } catch (...) { return -3; }
}

extern "C" JNIEXPORT jint JNICALL
Java_com_sari_camera_NativeEngine_alignAndStackRGBA(JNIEnv* e, jobject, jobjectArray arr, jobject out, jint w, jint h, jfloat sigma) {
    auto* b = (uint8_t*)e->GetDirectBufferAddress(out);
    if (!b || !arr || w <= 0 || h <= 0) return -1;
    const jlong need = (jlong)w * h * 4;
    if (e->GetDirectBufferCapacity(out) < need) return -1;
    jsize n = e->GetArrayLength(arr);
    std::vector<const uint8_t*> p;
    p.reserve(n);
    for (jsize i = 0; i < n; i++) {
        jobject o = e->GetObjectArrayElement(arr, i);
        const uint8_t* ptr = o ? (const uint8_t*)e->GetDirectBufferAddress(o) : nullptr;
        if (ptr && e->GetDirectBufferCapacity(o) >= need) p.push_back(ptr);
        if (o) e->DeleteLocalRef(o);
    }
    if (p.size() < 2) return -1;
    try { return sari_stack_rgba(p.data(), (int)p.size(), b, w, h, sigma); } catch (...) { return -3; }
}

extern "C" JNIEXPORT jint JNICALL
Java_com_sari_camera_NativeEngine_detectStars(JNIEnv* e, jobject, jobject buf, jint w, jint h, jint stride, jfloat sigma) {
    auto* p = (const uint8_t*)e->GetDirectBufferAddress(buf);
    if (!p || w <= 2 || h <= 2 || stride < w) { throwEx(e, "Direct buffer required"); return -1; }
    // Rust reads (h-1)*stride + w bytes; make sure the Java buffer really has them.
    if (e->GetDirectBufferCapacity(buf) < (jlong)(h - 1) * stride + w) { throwEx(e, "Buffer too small"); return -1; }
    try {
        std::vector<RustStar> stars(4096);
        return sari_detect_stars(p, w, h, stride, sigma, stars.data(), (int)stars.size());
    } catch (...) { return -3; }
}
