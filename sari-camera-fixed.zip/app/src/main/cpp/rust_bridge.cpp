// The Rust astro entry point (sari_detect_stars) is declared and called from sari_jni.cpp.
// This translation unit is kept so the CMake source list stays stable.
#include <cstdint>
