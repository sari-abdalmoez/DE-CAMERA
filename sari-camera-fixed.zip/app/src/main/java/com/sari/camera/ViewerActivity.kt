package com.sari.camera

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

class ViewerActivity : ComponentActivity() {
    private lateinit var image: ImageView
    private var uri: Uri? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val u = intent.data
        if (u == null) { finish(); return }
        uri = u
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }
        image = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        root.addView(image, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun action(label: String, onClick: () -> Unit) {
            bar.addView(Button(this).apply {
                text = label
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener { onClick() }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        action("SHARE") {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = contentResolver.getType(u) ?: "image/*"
                putExtra(Intent.EXTRA_STREAM, u)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "Share"))
        }
        action("DELETE") {
            try { contentResolver.delete(u, null, null) } catch (_: Throwable) {
                Toast.makeText(this, "Could not delete", Toast.LENGTH_SHORT).show()
            }
            finish()
        }
        action("INFO") {
            Toast.makeText(this, intent.getStringExtra("name") ?: "image", Toast.LENGTH_LONG).show()
        }
        root.addView(bar)
        setContentView(root)
        load(u)
    }

    /** Decodes a screen-sized sample; a full 12-16 MP bitmap would be ~64 MB. */
    private fun load(u: Uri) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            val limit = 2048
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > limit) sample *= 2
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, opts) }
            if (bmp != null) image.setImageBitmap(bmp)
            else startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (_: Throwable) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } catch (_: Throwable) { }
        }
    }
}
