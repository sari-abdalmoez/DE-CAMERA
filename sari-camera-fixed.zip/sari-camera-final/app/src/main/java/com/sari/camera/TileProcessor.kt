package com.sari.camera

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import java.nio.ByteBuffer
import kotlin.math.min

/** Bounded, overlapping tiles with conservative AI fallback and feathered seam blending. */
class TileProcessor(
    private val tileSize: Int,
    private val overlap: Int = 48,
    private val ai: AiEngine? = null,
    private val faceBoxes: List<RectF> = emptyList()
) {
    fun process(src: Bitmap, strength: Float): Bitmap {
        val scale = ai?.takeIf { it.available }?.scale ?: 1
        val outW = src.width * scale
        val outH = src.height * scale
        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val accum = FloatArray(outW * outH * 4)
        val weights = FloatArray(outW * outH)
        val step = (tileSize - overlap * 2).coerceAtLeast(64)
        var y = 0
        while (y < src.height) {
            var x = 0
            while (x < src.width) {
                val l = (x - overlap).coerceAtLeast(0)
                val t = (y - overlap).coerceAtLeast(0)
                val r = min(src.width, x + tileSize + overlap)
                val b = min(src.height, y + tileSize + overlap)
                val tile = Bitmap.createBitmap(src, l, t, r - l, b - t)
                val protected = faceBoxes.any { RectF.intersects(it, l.toFloat(), t.toFloat(), r.toFloat(), b.toFloat()) }
                val tileOut = runTile(tile, (if (protected) strength * 0.22f else strength).coerceIn(0f, 1f), scale, protected)
                blend(accum, weights, tileOut, x - l, y - t, x * scale, y * scale, scale, step, src.width, src.height, tile.width * scale, tile.height * scale)
                tile.recycle(); tileOut.recycle()
                x += step
            }
            y += step
        }
        val pixels = IntArray(outW * outH)
        for (i in pixels.indices) {
            val base = i * 4
            val w = weights[i].coerceAtLeast(1e-6f)
            val rr = (accum[base] / w).coerceIn(0f, 255f).toInt()
            val gg = (accum[base + 1] / w).coerceIn(0f, 255f).toInt()
            val bb = (accum[base + 2] / w).coerceIn(0f, 255f).toInt()
            val aa = (accum[base + 3] / w).coerceIn(0f, 255f).toInt()
            pixels[i] = Color.argb(aa, rr, gg, bb)
        }
        out.setPixels(pixels, 0, outW, 0, 0, outW, outH)
        return out
    }

    private fun runTile(tile: Bitmap, strength: Float, scale: Int, faceProtected: Boolean): Bitmap {
        val w = tile.width; val h = tile.height
        val ints = IntArray(w * h); tile.getPixels(ints, 0, w, 0, 0, w, h)
        val plane = w * h
        val input = FloatArray(3 * plane)
        for (i in ints.indices) {
            val c = ints[i]
            input[i] = Color.red(c) / 255f
            input[plane + i] = Color.green(c) / 255f
            input[2 * plane + i] = Color.blue(c) / 255f
        }

        // Deblur model is same-size. Blend conservatively with the original so the network cannot
        // freely replace captured content. This is deliberately not face beautification.
        if (ai?.deblurAvailable == true && w >= 384 && h >= 384 && !faceProtected) {
            val restored = ai.inferDeblur(input, h, w)
            if (restored != null && restored.size == 3 * plane) {
                val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val op = IntArray(plane)
                for (i in 0 until plane) {
                    val r = input[i] * 255f * (1f - 0.32f * strength) + restored[i].coerceIn(0f, 1f) * 255f * (0.32f * strength)
                    val g = input[plane + i] * 255f * (1f - 0.32f * strength) + restored[plane + i].coerceIn(0f, 1f) * 255f * (0.32f * strength)
                    val b = input[2 * plane + i] * 255f * (1f - 0.32f * strength) + restored[2 * plane + i].coerceIn(0f, 1f) * 255f * (0.32f * strength)
                    op[i] = Color.rgb(r.coerceIn(0f,255f).toInt(), g.coerceIn(0f,255f).toInt(), b.coerceIn(0f,255f).toInt())
                }
                out.setPixels(op, 0, w, 0, 0, w, h)
                return if (scale == 1 || ai?.superResolutionAvailable != true) out else superResolve(out, scale)
            }
        }

        if (ai?.superResolutionAvailable == true) {
            val result = ai.inferSuper(input, h, w)
            val ow = w * scale; val oh = h * scale
            if (result != null && result.size == 3 * ow * oh) {
                val out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
                val op = IntArray(ow * oh)
                for (i in op.indices) {
                    op[i] = Color.rgb(
                        (result[i].coerceIn(0f, 1f) * 255f).toInt(),
                        (result[ow * oh + i].coerceIn(0f, 1f) * 255f).toInt(),
                        (result[2 * ow * oh + i].coerceIn(0f, 1f) * 255f).toInt())
                }
                out.setPixels(op, 0, ow, 0, 0, ow, oh)
                val bicubic = Bitmap.createScaledBitmap(tile, ow, oh, true)
                val canvas = android.graphics.Canvas(bicubic)
                val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { alpha = (32 + 70 * strength).toInt().coerceIn(32, 102) }
                canvas.drawBitmap(out, 0f, 0f, paint)
                out.recycle()
                return bicubic
            }
        }

        val inputBuffer = ByteBuffer.allocateDirect(w * h * 4)
        tile.copyPixelsToBuffer(inputBuffer); inputBuffer.rewind()
        val processed = ByteBuffer.allocateDirect(w * h * 4)
        NativeEngine.processTileRGBA(inputBuffer, processed, w, h, strength)
        processed.rewind()
        val base = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        base.copyPixelsFromBuffer(processed)
        return if (scale == 1) base else Bitmap.createScaledBitmap(base, w * scale, h * scale, true).also { base.recycle() }
    }

    private fun superResolve(input: Bitmap, scale: Int): Bitmap {
        if (scale == 1 || ai?.superResolutionAvailable != true) return input
        val w = input.width; val h = input.height; val plane = w * h
        val ints = IntArray(plane); input.getPixels(ints, 0, w, 0, 0, w, h)
        val f = FloatArray(3 * plane)
        for (i in 0 until plane) {
            val c = ints[i]; f[i] = Color.red(c) / 255f; f[plane+i] = Color.green(c) / 255f; f[2*plane+i] = Color.blue(c) / 255f
        }
        val result = ai.inferSuper(f, h, w) ?: return input
        val ow = w * scale; val oh = h * scale
        if (result.size != 3 * ow * oh) return input
        val out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888); val op = IntArray(ow * oh)
        for (i in op.indices) op[i] = Color.rgb((result[i].coerceIn(0f,1f)*255f).toInt(), (result[ow*oh+i].coerceIn(0f,1f)*255f).toInt(), (result[2*ow*oh+i].coerceIn(0f,1f)*255f).toInt())
        out.setPixels(op,0,ow,0,0,ow,oh)
        val bicubic = Bitmap.createScaledBitmap(input, ow, oh, true)
        val canvas = android.graphics.Canvas(bicubic)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { alpha = (48 + 64 * 0.5f).toInt() }
        canvas.drawBitmap(out, 0f, 0f, paint)
        out.recycle(); input.recycle(); return bicubic
    }

    private fun blend(acc: FloatArray, weights: FloatArray, tile: Bitmap, cropX: Int, cropY: Int,
                      dstX: Int, dstY: Int, scale: Int, core: Int, srcW: Int, srcH: Int, tw: Int, th: Int) {
        val px = IntArray(tw * th); tile.getPixels(px, 0, tw, 0, 0, tw, th)
        val coreW = min(core, srcW - dstX / scale)
        val coreH = min(core, srcH - dstY / scale)
        val startX = cropX * scale
        val startY = cropY * scale
        val endX = min(tw, (cropX + coreW) * scale)
        val endY = min(th, (cropY + coreH) * scale)
        for (yy in startY until endY) for (xx in startX until endX) {
            val ox = dstX + (xx - startX); val oy = dstY + (yy - startY)
            if (ox !in 0 until srcW * scale || oy !in 0 until srcH * scale) continue
            val srcX = xx / scale
            val srcY = yy / scale
            val edgeX = min(srcX, (tw / scale) - 1 - srcX).toFloat()
            val edgeY = min(srcY, (th / scale) - 1 - srcY).toFloat()
            val w = (min(1f, (edgeX + 1f) / overlap) * min(1f, (edgeY + 1f) / overlap)).coerceAtLeast(0.08f)
            val c = px[yy * tw + xx]; val idx = oy * srcW * scale + ox; val b = idx * 4
            acc[b] += Color.red(c) * w; acc[b + 1] += Color.green(c) * w; acc[b + 2] += Color.blue(c) * w; acc[b + 3] += 255f * w; weights[idx] += w
        }
    }

}
