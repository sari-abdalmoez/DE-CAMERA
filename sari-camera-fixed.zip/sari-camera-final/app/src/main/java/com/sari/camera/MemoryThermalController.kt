package com.sari.camera

import android.app.ActivityManager
import android.content.Context
import android.os.PowerManager
import android.os.Process

class MemoryThermalController(private val context: Context) {
    enum class Profile { LOW_MEMORY, BALANCED, HIGH_PERFORMANCE }
    data class Budget(val profile: Profile, val tile: Int, val workers: Int, val maxFrames: Int, val aiScale: Float)
    fun budget(): Budget {
        val am = context.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo().also(am::getMemoryInfo)
        val total = mi.totalMem / (1024L*1024L)
        val avail = mi.availMem / (1024L*1024L)
        val thermal = context.getSystemService(PowerManager::class.java).currentThermalStatus
        return when {
            mi.lowMemory || total <= 3072 || avail < 700 || thermal >= PowerManager.THERMAL_STATUS_SEVERE -> Budget(Profile.LOW_MEMORY, 512, 1, 6, .75f)
            total >= 6144 && avail >= 2200 && thermal <= PowerManager.THERMAL_STATUS_MODERATE -> Budget(Profile.HIGH_PERFORMANCE, 1024, 3, 12, 1f)
            else -> Budget(Profile.BALANCED, 768, 2, 8, .85f)
        }
    }
}
